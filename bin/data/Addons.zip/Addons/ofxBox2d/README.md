![ofxBox2d](http://farm7.staticflickr.com/6010/5964216482_a11debc021_b.jpg)

This is a simple wrapper for box2d using Openframeworks. The examples below are still in progressive, but should be stable for the most part. Please open up a issue if you have suggestions or find bugs. 

thanks,
Todd

Install:
For all the example in ofxBox2d they include the addon/ofxBox2d. This is for easier development on the addon. 

If you would like you can add addon/ofxBox2d to OF/addons
 