/*
 *  ofxSimpleGuiControlWithValue.cpp
 *  MSA demo
 *
 *  Created by Mehmet Akten on 18/08/2010.
 *  Copyright 2010 MSA Visuals Ltd. All rights reserved.
 *
 */


